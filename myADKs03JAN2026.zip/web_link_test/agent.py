# C:\adk_agents\link_qna_agent\agent.py

import requests
from bs4 import BeautifulSoup

from google.adk.agents import Agent

# Optional JS-rendering support
try:
    from requests_html import HTMLSession
except ImportError:
    HTMLSession = None


def fetch_url_content(url: str, max_chars: int = 12000) -> dict:
    """
    Fetch and return plain text content from a public web page.

    Args:
        url: HTTP or HTTPS URL of the web page to fetch.
        max_chars: Maximum number of characters of cleaned text to return.

    Returns:
        {
          "url": "<the URL fetched>",
          "content": "<plain text content (possibly truncated)>"
        }

    This function is defensive: instead of raising exceptions on network/HTTP/parse
    errors, it returns a short diagnostic message in the `content` field so that
    the agent can respond gracefully instead of failing with an internal error.
    """
    def _make_headers():
        # Browser-like headers to reduce basic bot blocking
        return {
            "User-Agent": (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/123.0.0.0 Safari/537.36"
            ),
            "Accept": (
                "text/html,application/xhtml+xml,application/xml;q=0.9,"
                "image/avif,image/webp,image/apng,*/*;q=0.8"
            ),
            "Accept-Language": "en-US,en;q=0.9",
        }

    if not (url.startswith("http://") or url.startswith("https://")):
        msg = (
            "Could not fetch content because the URL must start with http:// or https://. "
            f"You provided: {url}"
        )
        print("=== fetch_url_content WARNING ===")
        print(msg)
        print("=== END WARNING ===")
        return {"url": url, "content": msg}

    # --------- 1) Plain requests + BeautifulSoup pass ----------
    try:
        resp = requests.get(url, timeout=30, headers=_make_headers())
    except Exception as e:
        msg = (
            f"Error fetching the URL: {e}. "
            "The site may be down, blocking automated access, or very slow to respond."
        )
        print("=== fetch_url_content ERROR (network) ===")
        print(msg)
        print("=== END ERROR ===")
        return {"url": url, "content": msg}

    if not (200 <= resp.status_code < 300):
        snippet = resp.text[:500] if resp.text else ""
        msg = (
            f"HTTP error while fetching the URL (status {resp.status_code}). "
            "I could not retrieve the page content successfully.\n\n"
            f"Response snippet:\n{snippet}"
        )
        print("=== fetch_url_content ERROR (http) ===")
        print(msg)
        print("=== END ERROR ===")
        return {"url": url, "content": msg}

    try:
        soup = BeautifulSoup(resp.text, "html.parser")
        for tag in soup(["script", "style", "noscript"]):
            tag.decompose()
        text = " ".join(soup.stripped_strings)
    except Exception as e:
        snippet = resp.text[:500] if resp.text else ""
        msg = (
            f"Error parsing HTML from the page: {e}. "
            "The structure of the page may be unusual or highly dynamic.\n\n"
            f"Raw HTML snippet:\n{snippet}"
        )
        print("=== fetch_url_content ERROR (parse) ===")
        print(msg)
        print("=== END ERROR ===")
        return {"url": url, "content": msg}

    # Decide if this plain-text result looks “too empty” / JS-only
    plain_text = text.strip()
    looks_js_only = (
        len(plain_text) < 300  # almost no text
        or "enable javascript" in plain_text.lower()
        or "please turn on javascript" in plain_text.lower()
    )

    # --------- 2) Optional JS-rendering fallback for JS-heavy pages ----------
    if looks_js_only and HTMLSession is not None:
        print("=== fetch_url_content INFO ===")
        print("Plain HTML looks sparse/JS-only. Trying JS rendering via requests_html...")
        print("=== END INFO ===")
        try:
            session = HTMLSession()
            r = session.get(url, headers=_make_headers(), timeout=30)
            # This spins up a headless browser (pyppeteer) and runs JS
            r.html.render(timeout=40, sleep=2)
            rendered_text = " ".join(r.html.text.split())
            if rendered_text.strip():
                print("=== DEBUG: first 500 chars of JS-rendered content ===")
                print(rendered_text[:500])
                print("=== END DEBUG ===")
                text = rendered_text
            else:
                print("=== fetch_url_content INFO ===")
                print("JS rendering produced no additional text.")
                print("=== END INFO ===")
        except Exception as e:
            print("=== fetch_url_content ERROR (js-render) ===")
            print(f"JS rendering failed: {e}")
            print("=== END ERROR ===")

    elif looks_js_only and HTMLSession is None:
        print("=== fetch_url_content INFO ===")
        print("Page seems JS-heavy, but requests_html is not installed. Skipping JS rendering.")
        print("=== END INFO ===")

    # If still nothing useful
    if not text.strip():
        msg = (
            "I fetched the page successfully, but there was no readable text after "
            "removing scripts/styles. The site may be heavily JavaScript-based, "
            "behind a login, or only showing a cookie/JavaScript enable message."
        )
        print("=== fetch_url_content INFO (empty text) ===")
        print(msg)
        print("=== END INFO ===")
        return {"url": url, "content": msg}

    # Truncate
    text = text[:max_chars]

    print("=== DEBUG: first 500 chars of final fetched content ===")
    print(text[:500])
    print("=== END DEBUG ===")

    return {"url": url, "content": text}


# IMPORTANT:
# We just pass `fetch_url_content` directly in `tools=[...]`.
# ADK will wrap it as a tool automatically based on its signature + docstring.
root_agent = Agent(
    model="gemini-2.0-flash",
    name="web_link_test",
    description="Answers questions based on the content of a given web link.",
    instruction="""
You are a web-reading assistant.

You have a tool named `fetch_url_content` that downloads and extracts plain-text
content from a web page given its URL.

Your behavior:

1. When the user asks about a specific URL, link, or web page, you MUST:
    - Call `fetch_url_content` with that URL.
    - Wait for the content.
    - Then answer the question based on the returned `content`.

2. Use whatever text you receive:
    - If the text clearly contains the article, reviews, or main content, summarize it,
      answer questions about it, or pull out key points.
    - If the text looks like a cookie banner, login wall, or “enable JavaScript” message,
      explain that you could not access the full content and answer only from what you can see.
    - If the tool returns an error message instead of page content, read that message
      and explain to the user what went wrong.

3. Do NOT refuse just because the site is a review site or commercial site.
    Instead:
    - Use the plain text you receive from `fetch_url_content`.
    - If reviews are present in the text, you may summarize them.
    - If they are not present, say that you cannot see specific reviews in the fetched content.

4. Never claim to have read or accessed information that is not present in the `content`.
    If something the user asks about is not visible in the fetched text, say so clearly.

5. If the user does not provide a URL, ask them for one.
""",
    tools=[fetch_url_content],
)