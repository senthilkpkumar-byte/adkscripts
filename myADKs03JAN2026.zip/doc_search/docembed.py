# -*- coding: utf-8 -*-
"""
Created on Fri Nov 28 11:16:38 2025

@author: 307003319

RAG File Processor: Flask service to upload files, generate embeddings,
and store them in a Chroma vector database for Retrieval-Augmented Generation (RAG).
"""

import os
import tempfile
from dotenv import load_dotenv
from flask import Flask, request, jsonify

# --- Import LangChain Libraries ---
# Note: UnstructuredWordDocumentLoader and UnstructuredExcelLoader require extra dependencies
from langchain_community.document_loaders import (
    PyPDFLoader,
    TextLoader,
    UnstructuredWordDocumentLoader,
    UnstructuredExcelLoader
)
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_google_genai import GoogleGenerativeAIEmbeddings
from langchain_community.vectorstores import Chroma

# --- Load Environment Variables ---
# Ensures GOOGLE_API_KEY is loaded from the .env file
load_dotenv()

# --- Flask App Initialization ---
app = Flask(__name__)

# --- Configuration ---
DB_PATH = os.path.join(os.path.dirname(__file__), 'chroma_db')

# Mapping file extensions to their corresponding loaders
LOADER_MAPPING = {
    ".pdf": PyPDFLoader,
    ".txt": TextLoader,
    # Requires 'unstructured' and supporting libs (e.g., 'python-docx')
    ".doc": UnstructuredWordDocumentLoader,
    ".docx": UnstructuredWordDocumentLoader,
    # Requires 'unstructured' and supporting libs (e.g., 'openpyxl')
    ".xls": UnstructuredExcelLoader,
    ".xlsx": UnstructuredExcelLoader,
}

def load_documents_from_files(files):
    """
    Loads documents from a list of uploaded files using the appropriate loader.
    Saves files temporarily to process them.
    """
    documents = []
    # Use a temporary directory for file storage during processing
    with tempfile.TemporaryDirectory() as temp_dir:
        for file in files:
            try:
                # Save the uploaded file to a temporary path
                temp_path = os.path.join(temp_dir, file.filename)
                file.save(temp_path)

                # Get the correct loader from the mapping
                ext = os.path.splitext(file.filename)[1].lower()
                
                if ext in LOADER_MAPPING:
                    loader_class = LOADER_MAPPING[ext]
                    # Instantiate and load the document
                    loader = loader_class(temp_path)
                    documents.extend(loader.load())
                else:
                    print(f"Warning: No loader found for file type '{ext}'. Skipping file: {file.filename}")
            except Exception as e:
                # Log any errors encountered during file processing
                print(f"Error processing file {file.filename}: {e}")
    return documents

@app.route('/adk_agents/process-files', methods=['POST'])
def process_files_endpoint():
    """
    API endpoint to upload and process multiple files for embeddings.
    """
    if 'files' not in request.files:
        return jsonify({"error": "No files part in the request"}), 400

    files = request.files.getlist('files')
    if not files or all(f.filename == '' for f in files):
        return jsonify({"error": "No selected files"}), 400

    print(f"Received {len(files)} file(s) for processing.")

    # 1. Load documents
    documents = load_documents_from_files(files)
    if not documents:
        print("No documents could be loaded from the provided files.")
        return jsonify({"error": "Could not load any documents from the uploaded files."}), 400

    print(f"Loaded {len(documents)} document(s) successfully.")

    # 2. Split documents into chunks
    print("Splitting documents...")
    text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=150)
    chunks = text_splitter.split_documents(documents)
    print(f"Split into {len(chunks)} chunks.")

    # 3. Create embeddings and index in ChromaDB
    try:
        print("Creating embeddings and indexing in ChromaDB...")
        # Ensure GOOGLE_API_KEY is available in environment variables
        embedding_function = GoogleGenerativeAIEmbeddings(model="models/text-embedding-004")
        
        # Create or update the vector store
        Chroma.from_documents(
            chunks, 
            embedding_function, 
            persist_directory=DB_PATH
        )

        print(f"--- Indexing complete! DB path: {DB_PATH} ---")
        return jsonify({
            "status": "success",
            "message": f"Successfully processed and indexed {len(documents)} document(s) into {len(chunks)} chunks."
        }), 200

    except Exception as e:
        print(f"An error occurred during embedding or indexing: {e}")
        return jsonify({"error": f"An error occurred: {e}"}), 500

if __name__ == "__main__":
    # In a production environment, use a production WSGI server (e.g., Gunicorn, Waitress)
    app.run()