import os
from langchain_community.vectorstores import Chroma
from langchain_google_genai import GoogleGenerativeAIEmbeddings

# Use your exact path logic
DB_PATH = os.path.join(os.path.dirname(__file__), 'chroma_db')

print(f"Checking path: {DB_PATH}")
print(f"Path exists: {os.path.exists(DB_PATH)}")

if os.path.exists(DB_PATH):
    print(f"Folder contents: {os.listdir(DB_PATH)}")

try:
    embeddings = GoogleGenerativeAIEmbeddings(model="models/text-embedding-004")
    db = Chroma(persist_directory=DB_PATH, embedding_function=embeddings)
    test_retriever = db.as_retriever()
    print("SUCCESS: Retriever created!")
except Exception as e:
    print(f"FAILURE: {e}")