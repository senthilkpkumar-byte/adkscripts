import os
from dotenv import load_dotenv

# --- 1. Load Environment Variables ---
load_dotenv()
API_KEY = os.getenv('GOOGLE_API_KEY')

# --- 2. Configuration ---
# Ensures the path is absolute and correctly handled
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, 'chroma_db')

# --- 3. Import Libraries ---
from google.adk.agents import Agent
from langchain_google_genai import GoogleGenerativeAIEmbeddings
from langchain_community.vectorstores import Chroma

# --- 4. Tool and Retriever Setup ---
retriever = None

if not API_KEY:
    print("[CRITICAL ERROR] GOOGLE_API_KEY not found in .env file.")
else:
    try:
        # Initialize embeddings with explicit API Key to avoid ADC credential errors
        embedding_function = GoogleGenerativeAIEmbeddings(
            model="models/text-embedding-004",
            google_api_key=API_KEY
        )

        # Check if the database directory actually exists and has files
        if os.path.exists(DB_PATH) and len(os.listdir(DB_PATH)) > 0:
            db = Chroma(
                persist_directory=DB_PATH, 
                embedding_function=embedding_function
            )
            retriever = db.as_retriever()
            print(f"[INFO] Successfully loaded Chroma DB from: {DB_PATH}")
        else:
            print(f"[WARNING] Database path '{DB_PATH}' is empty or does not exist.")
            
    except Exception as e:
        print(f"[ERROR] Failed to initialize Vector Store: {e}")

# --- 5. Tool Definition ---
def retrieve_context(query: str) -> str:
    """
    Retrieves the most relevant document snippets based on a user's query.
    """
    # GUARD CLAUSE: Prevents 'NoneType' has no attribute 'invoke'
    if retriever is None:
        return "ERROR: The document database is currently unavailable. Please check the server configuration."

    print(f"[TOOL] Retrieving context for query: '{query}'")
    
    try:
        docs = retriever.invoke(query)
        if not docs:
            return "No relevant documents were found for this query."
            
        # Extract and join content
        context = "\n---\n".join([doc.page_content for doc in docs])
        return context
    except Exception as e:
        return f"Error during document retrieval: {str(e)}"

# --- 6. Agent Instruction and Definition ---
RAG_INSTRUCTION = """
You are a specialized RAG agent. You MUST answer user questions using ONLY the provided context.

Process:
1. Call 'retrieve_context' with the user's exact query.
2. If the tool returns an error or no information, say: 'I could not find an answer in the provided documents.'
3. Otherwise, summarize the answer based strictly on the retrieved text.
"""

root_agent = Agent(
    name="doc_search",
    model="gemini-2.0-flash",
    description="An agent that answers questions about local documents using ChromaDB.",
    instruction=RAG_INSTRUCTION,
    tools=[retrieve_context],
)