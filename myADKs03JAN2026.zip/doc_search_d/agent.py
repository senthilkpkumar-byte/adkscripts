import os
from dotenv import load_dotenv
from google.adk.agents import Agent
from langchain_google_genai import GoogleGenerativeAIEmbeddings
from langchain_community.vectorstores import Chroma

# --- 1. Load Environment Variables ---
load_dotenv()
API_KEY = os.getenv('GOOGLE_API_KEY')

# --- 2. The Tool: Dynamic Folder Reader ---
def retrieve_context(query: str, db_path: str) -> str:
    """
    Connects to a specific folder path and retrieves document snippets.
    
    Args:
        query: The user's question.
        db_path: The local folder path where embeddings are stored.
    """
    if not API_KEY:
        return "ERROR: Google API Key is missing."

    # Validate that the folder actually exists
    if not os.path.exists(db_path):
        return f"ERROR: The folder path '{db_path}' was not found on this server."

    try:
        # Initialize embeddings
        embedding_function = GoogleGenerativeAIEmbeddings(
            model="models/text-embedding-004",
            google_api_key=API_KEY
        )

        # Initialize Chroma using only the directory path
        # It will automatically look for the index files inside this folder
        db = Chroma(
            persist_directory=db_path, 
            embedding_function=embedding_function
        )
        
        # Search for context
        docs = db.as_retriever().invoke(query)
        
        if not docs:
            return "Folder accessed, but no relevant text matches the query."
            
        return "\n---\n".join([doc.page_content for doc in docs])

    except Exception as e:
        return f"Error reading vector data at {db_path}: {str(e)}"

# --- 3. Agent with Strict Dynamic Rules ---
STRICT_INSTRUCTION = """
--- Dynamic Context Rules (STRICTLY FOLLOW THESE) ---
* **Primary Data Source:** You MUST look for a 'CURRENT CONTEXT BLOCK' in the user's message.
* **If Context Exists:** 1. Extract the folder path from 'Target Schema'.
    2. Pass that path and the user's question to the 'retrieve_context' tool.
* **If Context Missing:** Inform the user: "I dont have permissions to query this schema/tables."

**Note:** Answer the user's question ONLY using information from the 'retrieve_context' tool.
"""

root_agent = Agent(
    name="doc_search_d",
    model="gemini-2.0-flash",
    description="Agent that reads local embedding folders dynamically.",
    instruction=STRICT_INSTRUCTION,
    tools=[retrieve_context],
)