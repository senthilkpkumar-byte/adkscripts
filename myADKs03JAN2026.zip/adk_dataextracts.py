import psycopg2
import json
from dotenv import load_dotenv
import os
from flask import request, jsonify 
import uuid

class datafetch:
    
    def __init__(self):
        load_dotenv()
        
        # Database connection parameters (consider using environment variables for production)
        self.DB_CONFIG = {
            "database": os.getenv("POSTGRES_DB"),
            "user": os.getenv("POSTGRES_UNAME"),
            "password": os.getenv("POSTGRES_PWD"),
            "host": os.getenv("POSTGRES_HOST"),
            "port": 5432
        }


    def db_connection(self):
        """Establishes and returns a PostgreSQL database connection."""
        conn = None
        try:
            conn = psycopg2.connect(**self.DB_CONFIG)
            print("Database connection successful!")
        except psycopg2.Error as e:
            print(f"Database connection failed: {e}")
            raise e # Re-raise to ensure calling functions handle connection errors
        return conn



    def get_data(self,InQuery):
        conn = None
        cur = None # Initialize cur to None as well
        try:
            conn = self.db_connection()
            cur = conn.cursor()

            cur.execute(InQuery)
            # Using SELECT 1 is more efficient as we only care about existence, not the data itself.
            rows = cur.fetchall() # Fetch just one row, as we only need to know if it exists

            if rows:
                     # Fetch column names
                colnames = [desc[0] for desc in cur.description]
        
                # Convert to list of dicts
                result = [dict(zip(colnames, row)) for row in rows]
        
                # Convert to JSON
                json_output = json.dumps(result, indent=4)
                #print(json_output)
        
                # Optional: return or save to file
                return result
            else:
                return jsonify({"status":"error","message": "No agents are assigned to you"}), 400

        except psycopg2.Error as db_err:
            print(f"❌ Database error in get_auth: {db_err}")
            return jsonify({"status":"error","message": "Unauthorized access"}), 400
        except Exception as e:
            return jsonify({"status":"error","message": {e}}), 400
            return "no"
        finally:
            if cur:
                cur.close()
            if conn:
                conn.close()


    def saveInteractions(self,user_id,session_id,label_txt,question,answer):
        conn = None
        cur = None # Initialize cur to None as well
        try:
            conn = self.db_connection()
            cur = conn.cursor()
            sql="""INSERT INTO aiagents.tb_ai_interactions (user_id,session_id,topic_label,question,answer) values (%s,%s,%s,%s,%s);"""
            cur.execute(sql,(user_id,session_id,label_txt,question,answer))
            conn.commit()

        except psycopg2.Error as db_err:
            print(f"❌ Database error in get_auth: {db_err}")
            return jsonify({"status":"error","message": "Unauthorized access"}), 400
        except Exception as e:
            return jsonify({"status":"error","message": {e}}), 400
            return "no"
        finally:
            if cur:
                cur.close()
            if conn:
                conn.close()


    def saveSessionLabel(self,user_id,session_id,label_txt):
            conn = None
            cur = None # Initialize cur to None as well
            try:
                conn = self.db_connection()
                cur = conn.cursor()
                sql="""INSERT INTO adk_sessions.sessions_label (user_id,session_id,label_txt) values (%s,%s,%s);"""
                cur.execute(sql,(user_id,session_id,label_txt))
                conn.commit()

            except psycopg2.Error as db_err:
                print(f"❌ Database error in get_auth: {db_err}")
                return jsonify({"status":"error","message": "Unauthorized access"}), 400
            except Exception as e:
                return jsonify({"status":"error","message": {e}}), 400
                return "no"
            finally:
                if cur:
                    cur.close()
                if conn:
                    conn.close()

    def saveAgents(self,user_id,agent_title,agent_desc,business_fn,business_sub_fn,agent_owner_grp,instructions,source_type,schema_txt,table_list):
            conn = None
            cur = None # Initialize cur to None as well
            try:
                conn = self.db_connection()
                cur = conn.cursor()
                agent_uuid = uuid.uuid4()
                sql="""INSERT INTO aiagents.tb_agents (agent_id,user_id,agent_title,agent_desc,business_fn,business_sub_fn,agent_owner_grp,instructions,source_type,schema_txt,table_list) values (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s);"""
                cur.execute(sql,(str(agent_uuid),user_id,agent_title,agent_desc,business_fn,business_sub_fn,agent_owner_grp,instructions,source_type,schema_txt,table_list))
                sql="""INSERT INTO aiagents.tb_userauth_agents (user_id,agent_id) values (%s,%s);"""
                cur.execute(sql,(str(user_id),str(agent_uuid)))
                conn.commit()
                return jsonify({"status":"success","message": "Agent created"}), 200

            except psycopg2.Error as db_err:
                print(f"❌ Database error in saveAgents: {db_err}")
                return jsonify({"status":"error","message": "Agent title already exist"}), 400
            except Exception as e:
                return jsonify({"status":"error","message": {e}}), 400
                return "no"
            finally:
                if cur:
                    cur.close()
                if conn:
                    conn.close()


    def getSessionLabel(self,session_id):
        conn = None
        cur = None # Initialize cur to None as well
        try:
            conn = self.db_connection()
            cur = conn.cursor()
            sql="""SELECT label_txt from adk_sessions.sessions_label where session_id::text=%s;"""
            cur.execute(sql,(session_id,))
            result = cur.fetchone()
            print("RESULT------------------------",result)
            return result[0] if result else None
        except psycopg2.Error as db_err:
            print(f"❌ Database error in get_auth: {db_err}")
            return jsonify({"status":"error","message": "Unauthorized access"}), 400
        except Exception as e:
            return jsonify({"status":"error","message": {e}}), 400
            return "no"
        finally:
            if cur:
                cur.close()
            if conn:
                conn.close()

    #ON CONFLICT strategy for both adding and removing users, we use a technique called an Upsert.
    def process_user_actions(self,data):
        """
        Processes a list of user actions (add/remove) for a specific agent 
        using the ON CONFLICT (Upsert) strategy.
        """
        user_data_list = data.get('user_data', [])
        
        conn = None
        cur = None # Initialize cur to None as well

        try:
            conn = self.db_connection()
            cur = conn.cursor()
            for item in user_data_list:
                user_id = item.get('user_id')
                agent_id = item.get('agent_id')
                action = item.get('action')

                # Convert 'add' to True and everything else (like 'remove') to False
                target_status = (action == 'add')

                # The "Upsert" Query
                # We use EXCLUDED.is_active to take the value from the VALUES clause
                query = """
                    INSERT INTO aiagents.tb_userauth_agents (agent_id, user_id, is_active)
                    VALUES (%s, %s, %s)
                    ON CONFLICT (agent_id, user_id) 
                    DO UPDATE SET is_active = EXCLUDED.is_active;
                """
                
                cur.execute(query, (agent_id, user_id, target_status))
                
                status_text = "GRANTED" if target_status else "REVOKED"
                print(f"[{action.upper()}] Permission {status_text} for {user_id} on agent {agent_id}")

            # Commit all changes at once
            conn.commit()
            return True

        except Exception as e:
            # If any single insert fails, the whole batch rolls back
            conn.rollback()
            print(f"Database Error: {e}")
            return False
        finally:
            cur.close()
            conn.close()

    def getDashVal(self,session_id,dash_name):
        conn = None
        cur = None # Initialize cur to None as well
        try:
            conn = self.db_connection()
            cur = conn.cursor()
            sql="""select dash_template from aiagents.tb_dashboard where agent_id::text=%s and lower(dash_name)=%s;"""
            cur.execute(sql,(session_id,dash_name,))
            result = cur.fetchone()
            print("RESULT------------------------",result)
            return result[0] if result else None
        except psycopg2.Error as db_err:
            print(f"❌ Database error in get_auth: {db_err}")
            return jsonify({"status":"error","message": "Unauthorized access"}), 400
        except Exception as e:
            return jsonify({"status":"error","message": {e}}), 400
            return "no"
        finally:
            if cur:
                cur.close()
            if conn:
                conn.close()

    def getDashboards(self,session_id):
            conn = None
            cur = None # Initialize cur to None as well
            try:
                conn = self.db_connection()
                cur = conn.cursor()
                sql="""select dash_name from aiagents.tb_dashboard where agent_id::text=%s;"""
                cur.execute(sql,(session_id,))
                result = cur.fetchall()
                print("RESULT------------------------",result)
                if result:
        # Join all dashboard names into one string separated by commas
                    return ", ".join([row[0] for row in result])
            except psycopg2.Error as db_err:
                print(f"❌ Database error in get_auth: {db_err}")
                return jsonify({"status":"error","message": "Unauthorized access"}), 400
            except Exception as e:
                return jsonify({"status":"error","message": {e}}), 400
                return "no"
            finally:
                if cur:
                    cur.close()
                if conn:
                    conn.close()
