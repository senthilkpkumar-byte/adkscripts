import os
from google.adk.agents import Agent
from google.adk.tools import google_search
from dotenv import load_dotenv

# Import the Base class used by the DatabaseSessionService
# NOTE: This internal import is sometimes necessary to customize table creation.
from google.adk.sessions.database_session_service import BaseModel 

# --- CRITICAL FIX: Set the schema on the Base Model ---
# This tells SQLAlchemy to create all tables (sessions, events, etc.) 
# in the 'adk_sessions' schema, overriding the database's search_path.
BaseModel.metadata.schema = "adk_sessions"

# --- Rest of your setup remains the same ---
load_dotenv() 

if not os.getenv("GOOGLE_API_KEY"):
    raise ValueError("GOOGLE_API_KEY environment variable not set. Please check your .env file.")

# AGENT DEFINITION
root_agent = Agent(
    name="GeneralAssistant",
    model="gemini-2.5-flash", 
    instruction=(
        "You are a general-purpose, helpful assistant. "
        "..."
    ),
    description="A versatile assistant capable of answering general questions and performing web searches.",
    tools=[google_search] 
)

print("GeneralAssistant Agent loaded successfully.")