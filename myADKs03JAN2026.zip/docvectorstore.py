# -*- coding: utf-8 -*-
import os
import tempfile
import uuid  # Added for dynamic naming
from dotenv import load_dotenv
from flask import Flask, request, jsonify

# --- Import LangChain Libraries ---
from langchain_community.document_loaders import (
    PyPDFLoader,
    TextLoader,
    UnstructuredWordDocumentLoader,
    UnstructuredExcelLoader
)
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_google_genai import GoogleGenerativeAIEmbeddings
from langchain_community.vectorstores import Chroma

# --- Load Environment Variables ---
load_dotenv()

app = Flask(__name__)

# --- Configuration ---
# Updated to your specific root path
BASE_CHROMA_DIR = "/home/senthil/adk_agents/doc_search/chroma_db/"

LOADER_MAPPING = {
    ".pdf": PyPDFLoader,
    ".txt": TextLoader,
    ".doc": UnstructuredWordDocumentLoader,
    ".docx": UnstructuredWordDocumentLoader,
    ".xls": UnstructuredExcelLoader,
    ".xlsx": UnstructuredExcelLoader,
}

def load_documents_from_files(files):
    documents = []
    with tempfile.TemporaryDirectory() as temp_dir:
        for file in files:
            try:
                temp_path = os.path.join(temp_dir, file.filename)
                file.save(temp_path)
                ext = os.path.splitext(file.filename)[1].lower()
                
                if ext in LOADER_MAPPING:
                    loader_class = LOADER_MAPPING[ext]
                    loader = loader_class(temp_path)
                    documents.extend(loader.load())
                else:
                    print(f"Warning: No loader found for file type '{ext}'. Skipping file: {file.filename}")
            except Exception as e:
                print(f"Error processing file {file.filename}: {e}")
    return documents

@app.route('/datalens/process-files', methods=['POST'])
def process_files_endpoint():
    """
    API endpoint to upload files and store them in a dynamically created UUID folder.
    """
    if 'files' not in request.files:
        return jsonify({"error": "No files part in the request"}), 400

    files = request.files.getlist('files')
    if not files or all(f.filename == '' for f in files):
        return jsonify({"error": "No selected files"}), 400

    # --- DYNAMIC FOLDER CREATION ---
    # 1. Generate a unique ID for this specific batch of files
    unique_id = str(uuid.uuid4())
    dynamic_db_path = os.path.join(BASE_CHROMA_DIR, unique_id)
    
    # 2. Ensure the base directory and the specific uuid folder exist
    os.makedirs(dynamic_db_path, exist_ok=True)

    print(f"Received {len(files)} file(s). Target path: {dynamic_db_path}")

    # Load documents
    documents = load_documents_from_files(files)
    if not documents:
        return jsonify({"error": "Could not load any documents from the uploaded files."}), 400

    # Split documents
    text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=150)
    chunks = text_splitter.split_documents(documents)

    # Create embeddings and index in ChromaDB
    try:
        embedding_function = GoogleGenerativeAIEmbeddings(model="models/text-embedding-004")
        
        # Save to the dynamic path
        Chroma.from_documents(
            chunks, 
            embedding_function, 
            persist_directory=dynamic_db_path
        )

        print(f"--- Indexing complete! DB path: {dynamic_db_path} ---")
        
        # Return the dynamic_db_path so the caller can pass it to the Agent
        return jsonify({
            "status": "success",
            "chroma_db_path": dynamic_db_path,
            "uuid": unique_id,
            "message": f"Processed {len(documents)} documents into {len(chunks)} chunks."
        }), 200

    except Exception as e:
        print(f"An error occurred: {e}")
        return jsonify({"error": str(e)}), 500

if __name__ == "__main__":
    app.run()