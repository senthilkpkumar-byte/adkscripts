# Save this file as main_pg.py

import os
import psycopg
from dotenv import load_dotenv # You'd need to install python-dotenv: pip install python-dotenv
from psycopg.rows import dict_row # To get results as dictionaries
import inspect # Import the inspect module

# Load environment variables from .env file
load_dotenv()

# Corrected imports based on your working ADK version
from google.adk.agents import Agent
# The BigQuery imports are not directly used with the PostgreSQLToolset
from google.adk.tools.bigquery import BigQueryCredentialsConfig
from google.adk.tools.bigquery import BigQueryToolset
from google.adk.tools.bigquery.config import BigQueryToolConfig
from google.adk.tools.bigquery.config import WriteMode
from psycopg_pool import ConnectionPool
from decimal import Decimal

import google.auth

# --- Custom Tool class with __name__ attribute (Remains the same) ---
class Tool:
    def __init__(self, name, description, func):
        self.name = name
        self.description = description
        self.func = func
        self.__name__ = name # <--- THIS IS THE CRITICAL FIX
        try:
            # Copy the signature from the original function
            self.__signature__ = inspect.signature(func)
        except ValueError:
            # Handle cases where the signature cannot be inspected (e.g., if func is not a standard function)
            pass

    def __call__(self, *args, **kwargs):
        return self.func(*args, **kwargs)

# --- PostgreSQL Toolset Implementation ---
class PostgreSQLToolset:
    """
    A custom toolset for interacting with a PostgreSQL database, mimicking the BigQueryToolset structure.
    """
    def __init__(self):
        # Retrieve PostgreSQL connection details from environment variables
        self.conninfo = {
            "host": os.getenv("PG_HOST"),
            "dbname": os.getenv("PG_DATABASE"),
            "user": os.getenv("PG_USER"),
            "password": os.getenv("PG_PASSWORD"),
            "port": os.getenv("PG_PORT", 5432) # Default PostgreSQL port

        }

    

        print("PostgreSQL Connection Pool Initialized.")

    def _get_connection(self):
        """Establishes and returns a PostgreSQL database connection."""
        # Use psycopg.connect with the connection info
        # Set row_factory to dict_row to access columns by name (similar to sqlite3.Row)
        conn = psycopg.connect(**self.conninfo, row_factory=dict_row)
        #return self.pool.connection() 
        return conn

    def list_table_ids(self, schema_name: str) -> list[str]:
            """Lists all table names in the specified PostgreSQL schema."""
            # PostgreSQL uses information_schema to list tables
            sql_query = """
                SELECT table_name
                FROM information_schema.tables
                WHERE table_schema = %s 
                AND table_type = 'BASE TABLE';
            """
            with self._get_connection() as conn:
                with conn.cursor() as cursor:
                    # Execute with the dynamic schema_name
                    tables = [row['table_name'] for row in cursor.execute(sql_query, (schema_name,)).fetchall()]
                    return tables

    def get_table_info(self, table_name: str, schema_name: str) -> dict:
            """
            Retrieves schema information for a given table in the specified schema.
            Returns a dictionary where keys are column names and values are their types.
            """
            # Query to get column name and data type from information_schema
            sql_query = f"""
                SELECT column_name, data_type, is_nullable
                FROM information_schema.columns
                WHERE table_schema = %s AND table_name = %s
                ORDER BY ordinal_position;
            """
            with self._get_connection() as conn:
                with conn.cursor() as cursor:
                    try:
                        # Execute with the dynamic schema_name and table_name
                        cursor.execute(sql_query, (schema_name, table_name,))
                        columns = {}
                        results = cursor.fetchall()

                        if not results:
                            # Check if table exists at all
                            check_table_query = "SELECT 1 FROM information_schema.tables WHERE table_schema = %s AND table_name = %s;"
                            cursor.execute(check_table_query, (schema_name, table_name,))
                            if not cursor.fetchone():
                                return {"error": f"Table '{table_name}' not found or inaccessible in '{schema_name}' schema."}

                        for row in results:
                            # Add a simple NOT NULL indicator instead of PK for simplicity
                            null_info = " NOT NULL" if row['is_nullable'] == 'NO' else ""
                            columns[row['column_name']] = row['data_type'] + null_info
                        return columns
                    except Exception as e:
                        return {"error": f"Error retrieving schema for '{schema_name}.{table_name}': {str(e)}"}
                
    def execute_sql(self, sql_query: str) -> list[dict]:
        """Executes an SQL query and returns the results as a list of dictionaries."""
        with self._get_connection() as conn:
            try:
                # Use conn.execute for simple queries, auto-commits for DDL/DML, but here we only query.
                # Since we are using dict_row factory, results will be dictionaries.
                # psycopg automatically starts a transaction
                results = conn.execute(sql_query).fetchall()
                # If the query was a SELECT, results is a list of dicts.
# --- START OF FIX ---
                cleaned_results = []
                for row in results:
                    cleaned_row = {}
                    for k, v in row.items():
                        # If the value is a Decimal object, convert it to a float
                        if isinstance(v, Decimal):
                            cleaned_row[k] = float(v) # Convert Decimal to float for JSON
                        else:
                            cleaned_row[k] = v
                    cleaned_results.append(cleaned_row)

                return cleaned_results
                # --- END OF FIX ---
                #return results
            except psycopg.Error as e:
                # Rollback transaction on error (psycopg handles this generally, but explicit is cleaner)
                conn.rollback()
                # Return the error in the list[dict] format for consistency
                return [{"error": str(e)}]

# --- Environment Setup (Create a .env file for configuration) ---
"""
# .env file content:
# Replace these with your actual PostgreSQL connection details
PG_HOST=localhost
PG_DATABASE=mydatabase
PG_USER=myuser
PG_PASSWORD=mypassword
PG_PORT=5432
"""

# --- Mimicking the original Agent Setup ---
# 1. PostgreSQL Tool and Configuration

# Initialize the PostgreSQLToolset
# It gets its configuration from environment variables
postgresql_toolset = PostgreSQLToolset()

# Wrap the PostgreSQLToolset methods using your custom Tool class
adk_postgresql_tools = [
    # 🚨 CHANGE 3: Update description to guide the LLM to use schema_name
    Tool(name='list_table_ids', description='Lists all table names in the specified PostgreSQL schema. Requires a `schema_name` argument.', func=postgresql_toolset.list_table_ids),
    # 🚨 CHANGE 4: Update description to guide the LLM to use schema_name
    Tool(name='get_table_info', description='Retrieves schema and column information for a table. Requires `table_name` and `schema_name` arguments.', func=postgresql_toolset.get_table_info),
    # execute_sql remains the same
    Tool(name='execute_sql', description='Executes an SQL query and returns the results.', func=postgresql_toolset.execute_sql),
]
# 2. Agent Definition with Enriched Instruction
PG_DATABASE_NAME = os.getenv("PG_DATABASE")
PG_HOST_NAME = os.getenv("PG_HOST")
#    * **Blocked Tables:** Explicitly avoid using any system schemas/tables (e.g., `pg_catalog`, `information_schema`).
# This variable MUST be named 'root_agent' for your ADK environment to find it.
root_agent = Agent(
    model="gemini-2.0-flash", # Using a recommended model
    name="datainsight_d_agent",
    description=(
        "The agent can provide answers to questions about data, databases, "
        "statistics, and analytics using a PostgreSQL database. It can also run data analysis."
    ),
    instruction=f"""
 You are an analytics agent that can answer questions on data, stored in a PostgreSQL database.

    **--- Dynamic Context Rules (STRICTLY FOLLOW THESE) ---**
    * **Primary Data Source:** You **MUST** look for a 'CURRENT CONTEXT BLOCK' in the user's message.
    * **If Context Exists:** Use the `Target Schema` and `Target Table` specified in that block as your primary focus for all subsequent queries.
    * **If Context Missing:** Inform the user that you dont have permissions to query this schema/tables.

    **--- PostgreSQL Data Context (General Rules) ---**
    * **Focus Database:** `{PG_DATABASE_NAME}` on host `{PG_HOST_NAME}`


**--- SQL Query Generation Guidelines (CRITICAL UPDATE) ---**
    * All SQL queries must be valid **PostgreSQL** syntax.
    * When constructing SQL queries, always use the **full path** (`schema.table_name`) based on the 'CURRENT CONTEXT BLOCK'.
    * Do not generate SQL queries that fetch all rows from a table. Instead, use WHERE clauses to filter data,
        or use GROUP BY clauses to aggregate data, or use ORDER BY clauses to sort data.
    * When selecting date or timestamp columns, you **MUST** cast them to `TEXT` using `CAST(column_name AS TEXT)` to prevent serialization errors. Example: `SELECT sku, CAST(expiry_date AS TEXT) FROM finance.monthly_sales_report LIMIT 5`
    
    * **Mandatory Tool Usage Format:** When generating a tool call, you MUST use the following syntax, including the `argument_name="value"` structure:
        1. **To list tables:** `list_table_ids(schema_name="[SCHEMA_NAME]")`
        2. **To get table schema:** `get_table_info(table_name="[TABLE_NAME]", schema_name="[SCHEMA_NAME]")`
        3. **To execute a query:** `execute_sql(sql_query="[VALID POSTGRESQL QUERY]")`

    * Always verify table and column names using **`get_table_info(...)`** before executing complex queries.
    * If you need to create a temporary table for complex analysis, ensure it's prefixed with `temp_`.
    
    **--- Python Plotting Guidelines ---**
    * When asked to generate plots, you should first retrieve the necessary data using `postgresql_toolset.execute_sql`.
    * Once you have the data, present it clearly to the user in a tabular or structured format, explaining that
        they can then use this data with their preferred plotting tools (e.g., Python's Matplotlib/Seaborn, Excel, etc.)
        to generate the desired charts.
    * Do NOT attempt to generate image files directly as charting tools are not available within this setup.

    Make full use of your `postgresql_toolset` to fulfill user requests, adhering strictly to these guidelines.
    * use schema name as prefix in all queries, e.g., pharma.table_name
    """,
    tools=adk_postgresql_tools, # Pass the list of wrapped tools
)