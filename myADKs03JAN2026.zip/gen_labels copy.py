# ==============================================================================
# 1. IMPORTS & CONFIGURATION
# ==============================================================================
import os
import google.generativeai as genai  # Switched from vertexai
from dotenv import load_dotenv
from flask import Flask, request, jsonify

# ==============================================================================
# 2. FLASK APP AND CONFIGURATION
# ==============================================================================
app = Flask(__name__)

# Load environment variables
load_dotenv()

MODEL_NAME = "gemini-2.0-flash" 
API_KEY = os.getenv('GOOGLE_API_KEY')

# Global variable for the model
generative_model = None

def initialize_gemini():
    """Initializes the Gemini API using only an API Key."""
    global generative_model
    try:
        print("[INFO] Starting application setup...")
        
        if not API_KEY:
            raise ValueError("GOOGLE_API_KEY environment variable not set in .env file.")

        # Configure the SDK with your API Key
        genai.configure(api_key=API_KEY)
        
        # Initialize the Generative Model globally
        generative_model = genai.GenerativeModel(MODEL_NAME)
        
        print(f"[INFO] Gemini API initialized successfully with model: {MODEL_NAME}.")
        return True
    except Exception as e:
        print(f"\n--- CONFIGURATION ERROR ---\nError Details: {e}")
        return False

# Initialize the model immediately
if not initialize_gemini():
    print("[ERROR] Critical failure: Could not initialize AI model.")

# ==============================================================================
# 3. AI LOGIC
# ==============================================================================
def generate_session_label(user_prompt: str, model: genai.GenerativeModel) -> str:
    """Uses the generative model to create a short, descriptive label."""
    try:
        prompt = f"""
        Based on the following user query, create a short, descriptive label (3-5 words).
        The label should act like a subject line.
        
        User Query: "{user_prompt}"
        Label:
        """
        response = model.generate_content(prompt)
        
        # --- ROBUST TEXT EXTRACTION ---
        # We manually collect text from all parts to avoid the 'Part is not iterable' error
        generated_text = ""
        try:
            if response.candidates and response.candidates[0].content.parts:
                parts = response.candidates[0].content.parts
                # Check if parts is a single object or a list
                if hasattr(parts, '__iter__') and not isinstance(parts, (str, bytes)):
                    generated_text = "".join([p.text for p in parts if hasattr(p, 'text')])
                else:
                    # If it's just a single Part object
                    generated_text = parts[0].text if hasattr(parts[0], 'text') else str(parts[0])
            else:
                generated_text = response.text # Fallback to standard method
        except Exception as inner_e:
            print(f"[DEBUG] Manual extraction failed: {inner_e}")
            generated_text = "General Conversation"

        # Clean up the string
        label = generated_text.strip().replace("*", "").replace("\"", "").replace("'", "")
        
        # Handle cases where the model might return an empty string or blocked response
        if not label or len(label) < 2:
            return "General Conversation"
            
        return label

    except Exception as e:
        print(f"ERROR: Could not generate session label. Reason: {e}")
        return "General Conversation"
# ==============================================================================
# 4. FLASK API ROUTE
# ==============================================================================
@app.route('/chat', methods=['POST'])
def chat_api():
    if generative_model is None:
        return jsonify({"error": "AI Model not initialized. Check server logs."}), 500
        
    try:
        data = request.get_json()
        if not data or 'user_prompt' not in data:
            return jsonify({"error": "Missing 'user_prompt' in request body."}), 400

        user_prompt = data.get('user_prompt')
        
        print(f"[INFO] Processing request: {user_prompt[:50]}...")
        conversation_label = generate_session_label(user_prompt, generative_model) 
        
        return jsonify({
            "status": "success",
            "conversation_label": conversation_label,
        })

    except Exception as e:
        print(f"[API ERROR] {e}")
        return jsonify({"error": str(e)}), 500

# ==============================================================================
# 5. MAIN EXECUTION BLOCK
# ==============================================================================
if __name__ == "__main__":
    # Ensure debug=True so you can see errors in the terminal
    app.run()