import os
from google.adk.agents import Agent
from google.adk.tools import google_search
from dotenv import load_dotenv

# --- 1. SETUP (Load Environment Variables) ---
load_dotenv() 


if not os.getenv("GOOGLE_API_KEY"):
    raise ValueError("GOOGLE_API_KEY environment variable not set. Please check your .env file.")

# --- 2. AGENT DEFINITION (Renamed to root_agent) ---

# RENAME the agent variable here to 'root_agent' 
# This is the variable name the ADK API Server is explicitly searching for.
root_agent = Agent(
    name="GeneralAssistant",
    model="gemini-2.5-flash", 
    instruction=(
        "You are a general-purpose, helpful assistant. "
        "Answer user questions accurately and concisely. "
        "For questions that require current, real-time information (like news, weather, or current events), "
        "you MUST use the 'google_search' tool."
    ),
    description="A versatile assistant capable of answering general questions and performing web searches.",
    tools=[google_search] 
)

# You can keep the AGENTS list if you prefer, but 'root_agent' alone is sufficient
# AGENTS = [root_agent] 

print("GeneralAssistant Agent loaded successfully.")