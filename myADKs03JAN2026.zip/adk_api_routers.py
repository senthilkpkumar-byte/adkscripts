from flask import Flask, request, jsonify,send_from_directory,make_response,send_file,abort
import json
import sqlite3
from flask_cors import CORS
import numpy
import random
import json
import os
from pandas import DataFrame
import requests
from huggingface_hub import InferenceClient
import pandas as pd
from dotenv import load_dotenv
import mimetypes
import tempfile
from langchain_community.document_loaders import (
    PyPDFLoader,
    TextLoader,
    UnstructuredWordDocumentLoader,
    UnstructuredExcelLoader
)
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_google_genai import GoogleGenerativeAIEmbeddings
from langchain_community.vectorstores import Chroma
import uuid
import mimetypes

# user defined library
from agents_useraccess import Login
#from save_conversation import dbControls
from adk_dataextracts import datafetch
from gen_labels import GeminiService
from dashboards import dashTemplates
from document_processor import datalens_bp


load_dotenv() 

app = Flask(__name__)
#CORS(app,origins=["http://localhost:3000","http://localhost:5173"])
#CORS(app,origins=["https://www.agentlense.ai/login",headers=['Content-Type','0qm82CNFNsIyr_aus-JxHIO94xCIF4kdh-Rxu2XKEww='],"https://react-aidash-al20sk0ik-datalens-projects.vercel.app/","http://localhost:5173","http://localhost:5000","https://clear-grouse-pumped.ngrok-free.app","http://localhost:3000"])

#CORS(app,origins=["https://www.agentlense.ai/login","https://react-aidash-al20sk0ik-datalens-projects.vercel.app/","http://localhost:5173","http://localhost:5000","https://clear-grouse-pumped.ngrok-free.app","http://localhost:3000"],headers=['Content-Type','0qm82CNFNsIyr_aus-JxHIO94xCIF4kdh-Rxu2XKEww='])
ADK_BASE_URL = "http://127.0.0.1:8000"         # ADK api_server URL
ADK_RUN_URL = f"{ADK_BASE_URL}/run"            # ADK /run endpoint
gemini_ai = GeminiService()
handleLabel=datafetch()
dashGen=dashTemplates()
IMAGE_DIRECTORY = "/home/senthil/adk_agents/chartimage/"

CORS(app, 
     resources={r"/*": {"origins": [
        "https://www.agentlense.ai",
        "https://www.agentlense.ai/login",
        "https://react-aidash-al20sk0ik-datalens-projects.vercel.app",
        "http://localhost:5173",
        "http://localhost:5000",
        "https://clear-grouse-pumped.ngrok-free.app",
        "http://localhost:3000",
        "http://localhost:8000",
        "https://agentgallery.netlify.app"
    ],
    "methods": ["GET", "POST", "OPTIONS"],
    "allow_headers": ["Content-Type", "Authorization", "api-key", "ngrok-skip-browser-warning"]}})

errMessage={"status":"error","message":"Issue with authorization or api key"}
th_apikey=os.getenv("TH_API_KEY")
print(th_apikey)
IMAGE_DIRECTORY = "/home/senthil/adk_agents/chartimage/"
app.register_blueprint(datalens_bp)

#@app.after_request
#def add_cors_headers(response):
#    response.headers["Access-Control-Allow-Origin"] = "https://www.agentlense.ai"
#    response.headers["Access-Control-Allow-Headers"] = "Content-Type, Authorization, ngrok-skip-browser-warning"
#    response.headers["Access-Control-Allow-Methods"] = "GET, POST, OPTIONS"
#    return response
def ensure_session(app_name: str, user_id: str, session_id: str):
    """
    Create (or reuse) a session for this user in ADK.
    POST /apps/{app_name}/users/{user_id}/sessions/{session_id}
    """
    session_url = f"{ADK_BASE_URL}/apps/{app_name}/users/{user_id}/sessions/{session_id}"
    print("DEBUG: POST session_url =", session_url)

    resp = requests.post(session_url, json={})
    print("DEBUG: session status =", resp.status_code, resp.text)

    if resp.status_code in (200, 201):
        # Session created/updated
        return

    # If session already exists, that's fine
    try:
        data = resp.json()
        detail = str(data.get("detail", ""))
        if "Session already exists" in detail:
            print("DEBUG: session already exists, continuing")
            return
    except Exception:
        pass

    # Any other error should be raised
    resp.raise_for_status()




def extract_final_text_from_events(events):
    """
    ADK /run returns a list of event objects.
    We scan for the last 'text' part in the content.
    """
    if not isinstance(events, list):
        return "Unexpected response format from ADK."

    last_text = None
    for event in events:
        if not isinstance(event, dict):
            continue
        content = event.get("content") or {}
        parts = content.get("parts") or []
        for part in parts:
            if isinstance(part, dict) and "text" in part:
                last_text = part["text"]

    return last_text or "No text response found from agent."


@app.route("/datalens/weblink", methods=["POST"])
def link_qna_agent_endpoint():
    """
    Public endpoint.

    Expected JSON input:
      {
        "question": "Hello, test from Senthil",
        "user_id": "optional-user-id"  # optional
      }

    Response JSON:
      {
        "answer": "Agent's final reply text",
        "events": [ ...raw ADK events... ]
      }
    """
    if(request.headers.get('api-key')==None):
        return errMessage
    else:
        api_key=request.headers.get('api-key').strip('"').strip('"')

    if(api_key==th_apikey): 
        data = request.get_json()
        if not data or "question" not in data:
            return jsonify({"error": "Request body must be JSON with a 'question' key."}), 400

        question = data["question"]
        user_id = data.get("user_id")
        # Simple session id per user
        session_id = data.get("session_id")
        authorization_id=data["user_id"]

        print(f"DEBUG: /ask question from {user_id!r}: {question!r}")

        try:
            # 1) Ensure an ADK session exists
            ensure_session("web_link_test", user_id, session_id)

            # 2) Build ADK /run payload (IMPORTANT: keys are camelCase)
            adk_payload = {
                "app_name": "web_link_test",
                "user_id": user_id,
                "session_id": session_id,
                "new_message": {
                    "role": "user",
                    "parts": [
                        {"text": question}
                    ],
                },
                "streaming": True,
            }

            print("DEBUG: POST ADK_RUN_URL =", ADK_RUN_URL)
            print("DEBUG: payload =", adk_payload)

            resp = requests.post(ADK_RUN_URL, json=adk_payload, timeout=120)
            print("DEBUG: /run status =", resp.status_code)
            print("DEBUG: /run body   =", resp.text)

            resp.raise_for_status()
            events = resp.json()

            # Extract a simple answer from the events
            answer = extract_final_text_from_events(events)
            handleLabel.saveInteractions(authorization_id,session_id,'websource',question,answer)

            return jsonify({
                "session_id":session_id,
                "user_id":authorization_id,
                "answer": answer,
            })

            return jsonify({
                "answer": answer,
                "session_id":session_id
            })

        except requests.exceptions.RequestException as e:
            error_message = f"Failed calling ADK at {ADK_RUN_URL}"
            print(f"ERROR: {error_message}\nDetails: {e}")
            return jsonify({"error": error_message, "details": str(e)}), 502
        except Exception as e:
            print(f"Unexpected error in Flask wrapper: {e}")
            return jsonify(
                {"error": "Internal error in Flask wrapper.", "details": str(e)}
            ), 500
    else:
        return errMessage

@app.route("/datalens/datainsight", methods=["POST"])
def di_cabs_agent_endpoint():
    """
    Public endpoint.

    Expected JSON input:
      {
        "question": "Hello, test from Senthil",
        "user_id": "optional-user-id"  # optional
      }

    Response JSON:
      {
        "answer": "Agent's final reply text",
        "events": [ ...raw ADK events... ]
      }
    """
    if(request.headers.get('api-key')==None):
        return errMessage
    else:
        api_key=request.headers.get('api-key').strip('"').strip('"')

    if(api_key==th_apikey):     
        data = request.get_json()
        if not data or "question" not in data:
            return jsonify({"error": "Request body must be JSON with a 'question' key."}), 400

        question = data["question"]
        session_id = data.get("session_id")
        authorization_id=data["authorization_id"]
        if not session_id:
            session_id = str(uuid.uuid4())
        # Simple session id per user
        #session_id = f"session-{user_id}"

        print(f"DEBUG: /datainsight question from {authorization_id!r}: {question!r}")

        try:
            # 1) Ensure an ADK session exists
            ensure_session("db_postgres_agent", authorization_id, session_id)

            # 2) Build ADK /run payload (IMPORTANT: keys are camelCase)
            adk_payload = {
                "app_name": "db_postgres_agent",
                "user_id": authorization_id,
                "session_id": session_id,
                "new_message": {
                    "role": "user",
                    "parts": [
                        {"text": question}
                    ],
                },
                "streaming": False,
            }

            print("DEBUG: POST ADK_RUN_URL =", ADK_RUN_URL)
            print("DEBUG: payload =", adk_payload)

            resp = requests.post(ADK_RUN_URL, json=adk_payload, timeout=120)
            print("DEBUG: /run status =", resp.status_code)
            print("DEBUG: /run body   =", resp.text)

            resp.raise_for_status()
            events = resp.json()

            # Extract a simple answer from the events
            answer = extract_final_text_from_events(events)

            return jsonify({
                "session_id":session_id,
                "authorization_id":authorization_id,
                "answer": answer,
            })

        except requests.exceptions.RequestException as e:
            error_message = f"Failed calling ADK at {ADK_RUN_URL}"
            print(f"ERROR: {error_message}\nDetails: {e}")
            return jsonify({"error": error_message, "details": str(e)}), 502
        except Exception as e:
            print(f"Unexpected error in Flask wrapper: {e}")
            return jsonify(
                {"error": "Internal error in Flask wrapper.", "details": str(e)}
            ), 500
    else:
        return errMessage


@app.route("/datalens/datainsight_d", methods=["POST"])
def di_dynamic_agent_endpoint():
    """
    Public endpoint.

    Expected JSON input:
      {
        "question": "Hello, test from Senthil",
        "user_id": "optional-user-id"  # optional
      }

    Response JSON:
      {
        "answer": "Agent's final reply text",
        "events": [ ...raw ADK events... ]
      }
    """
    if(request.headers.get('api-key')==None):
        return errMessage
    else:
        api_key=request.headers.get('api-key').strip('"').strip('"')

    if(api_key==th_apikey):     
        data = request.get_json()
        if not data or "question" not in data:
            return jsonify({"error": "Request body must be JSON with a 'question' key."}), 400

        question = data["question"]
# --- NEW: Extract Contextual Parameters ---
        context_data = data.get("context", {})
        dynamic_schema = context_data.get("schema")
        dynamic_table = context_data.get("table_name")
# ------------------------------------------
        session_id = data.get("session_id")
        authorization_id=data["user_id"]
        question_parts=question.split()
        if not session_id:
            session_id = str(uuid.uuid4())
        # Simple session id per user
        #session_id = f"session-{user_id}"

        print(f"DEBUG: /datainsight question from {authorization_id!r}: {question!r}")
        if question_parts[0]=='@dashboards' or question_parts[0]=='@dashboard':
            if len(question_parts)==1:
                dashboards=handleLabel.getDashboards(session_id)
                if not dashboards:
                    return jsonify({
                    "answer":"No dashboard exist for this agent"
                    })
                print('*************************',dashboards)
                formatted_dash = dashboards.replace(", ", "\n* ")
                return jsonify({
                    "answer": f"**Available Dashboards**\n* {formatted_dash}\n\n*To view **dashboard** type the prompt as shown in the example below\n eg: @dashboard inventory_dash"
                })
            
            else:
                dashVal=handleLabel.getDashVal(session_id,question_parts[1].lower())
            if not dashVal:
                return jsonify({
                    "answer":"No such dashboard exist"
                })
            dashInput=dashVal.replace('\r\n', '').replace('\n', '').replace('\r', '')
            filename=dashGen.dashBoard(dashInput)
            print('-----------**********-----------\n',filename)
            print(IMAGE_DIRECTORY)
            handleLabel.saveInteractions(authorization_id,session_id,question_parts[1].lower(),'dashboard',filename)
            return send_from_directory(IMAGE_DIRECTORY, filename)
        else:
                
            try:
                # 1) Ensure an ADK session exists
                ensure_session("datainsight_d_agent", authorization_id, session_id)

    # --- NEW: Build the Context Block for the Agent ---
                if dynamic_schema and dynamic_table:
                    print("*************************** DYNAMIC")
                    context_block = f"""
                    ### CURRENT CONTEXT BLOCK (CRITICAL INSTRUCTION) ###
                    * **Target Schema:** `{dynamic_schema}`
                    * **Target Table:** `{dynamic_table}`
                    * **Focused Tables:** Explicitly respond only to tables listed in the array {dynamic_table}.
                    * **dont respond to questions related to table outside the array list
                    ### END CONTEXT BLOCK ###

                    """
                    #* **Query Rule:** All SQL queries MUST use the full path, e.g., `{dynamic_schema}.{dynamic_table}`.

                else:
                    print("*************************** NO DYNAMIC")
                    context_block = "" # No dynamic context, rely on agent's default instruction (e.g., 'pharma')

                # Combine the context block with the user's question
                full_prompt = context_block + question
                # ----------------------------------------------------

                # 2) Build ADK /run payload (IMPORTANT: keys are camelCase)

                # 2) Build ADK /run payload (IMPORTANT: keys are camelCase)
                adk_payload = {
                    "app_name": "datainsight_d_agent",
                    "user_id": authorization_id,
                    "session_id": session_id,
                    "new_message": {
                        "role": "user",
                        "parts": [
                            {"text": full_prompt}
                        ],
                    },
                    "streaming": False,
                }

                print("DEBUG: POST ADK_RUN_URL =", ADK_RUN_URL)
                print("DEBUG: payload =", adk_payload)

                resp = requests.post(ADK_RUN_URL, json=adk_payload, timeout=120)
                print("DEBUG: /run status =", resp.status_code)
                print("DEBUG: /run body   =", resp.text)

                resp.raise_for_status()
                events = resp.json()

                # Extract a simple answer from the events
                answer = extract_final_text_from_events(events)
                handleLabel.saveInteractions(authorization_id,session_id,'datainsight',question,answer)

                return jsonify({
                    "session_id":session_id,
                    "user_id":authorization_id,
                    "answer": answer,
                })

            except requests.exceptions.RequestException as e:
                error_message = f"Failed calling ADK at {ADK_RUN_URL}"
                print(f"ERROR: {error_message}\nDetails: {e}")
                return jsonify({"error": error_message, "details": str(e)}), 502
            except Exception as e:
                print(f"Unexpected error in Flask wrapper: {e}")
                return jsonify(
                    {"error": "Internal error in Flask wrapper.", "details": str(e)}
                ), 500
            else:
                return errMessage


@app.route("/datalens/dashboards", methods=["POST"])
def getDashboards():
    """
    Public endpoint.

    Expected JSON input:
      {
        "question": "Hello, test from Senthil",
        "user_id": "optional-user-id"  # optional
      }

    Response JSON:
      {
        "answer": "Agent's final reply text",
        "events": [ ...raw ADK events... ]
      }
    """
    if(request.headers.get('api-key')==None):
        return errMessage
    else:
        api_key=request.headers.get('api-key').strip('"').strip('"')

    if(api_key==th_apikey):     
        data = request.get_json()
        if not data or "dashboard" not in data:
            return jsonify({"error": "Request body must be JSON with a 'dashboard' key."}), 400

        filename = data["dashboard"]
        return send_from_directory(IMAGE_DIRECTORY, filename)

@app.route("/datalens/docsearch_d", methods=["POST"])
def docsearchd_agent_endpoint():
    # ... (Keep your existing API Key validation logic) ...
    
    data = request.get_json()
    question = data.get("question")
    user_id = data.get("user_id")
    session_id = data.get("session_id")
    authorization_id=data["user_id"]
    
    # Path where your embedding script saved the data
    # Example from payload: "C:/projects/my_app/storage/folder_123"
    local_folder_path = data.get("chroma_db_path")

    # --- Constructing the Prompt with the Context Block ---
    if local_folder_path:
        final_prompt = f"""
        CURRENT CONTEXT BLOCK:
        Target Schema: {local_folder_path}

        User Question: {question}
        """
    else:
        # If no path is provided, the Agent triggers the "No Permission" rule
        final_prompt = question

    try:
        ensure_session("doc_search_d", user_id, session_id)

        adk_payload = {
            "app_name": "doc_search_d",
            "user_id": user_id,
            "session_id": session_id,
            "new_message": {
                "role": "user",
                "parts": [{"text": final_prompt}],
            },
            "streaming": False,
        }

        resp = requests.post(ADK_RUN_URL, json=adk_payload, timeout=120)
        resp.raise_for_status()
        
        events = resp.json()
        answer = extract_final_text_from_events(events)
        handleLabel.saveInteractions(authorization_id,session_id,'docsearch',question,answer)
        return jsonify({
            "answer": answer,
            "session_id": session_id,
            "user_id": user_id
        })

    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/datalens/docsearch", methods=["POST"])
def docsearc_agent_endpoint():
    """
    Public endpoint.

    Expected JSON input:
      {
        "question": "Hello, test from Senthil",
        "user_id": "optional-user-id"  # optional
      }

    Response JSON:
      {
        "answer": "Agent's final reply text",
        "events": [ ...raw ADK events... ]
      }
    """
    if(request.headers.get('api-key')==None):
        return errMessage
    else:
        api_key=request.headers.get('api-key').strip('"').strip('"')

    if(api_key==th_apikey):   
        data = request.get_json()
        if not data or "question" not in data:
            return jsonify({"error": "Request body must be JSON with a 'question' key."}), 400


        question = data["question"]
        user_id=data["user_id"]
        session_id = data.get("session_id")

        print(f"DEBUG: /datainsight question from {user_id!r}: {question!r}")

        try:
            # 1) Ensure an ADK session exists
            ensure_session("doc_search", user_id, session_id)

            # 2) Build ADK /run payload (IMPORTANT: keys are camelCase)
            adk_payload = {
                "app_name": "doc_search",
                "user_id": user_id,
                "session_id": session_id,
                "new_message": {
                    "role": "user",
                    "parts": [
                        {"text": question}
                    ],
                },
                "streaming": False,
            }

            print("DEBUG: POST ADK_RUN_URL =", ADK_RUN_URL)
            print("DEBUG: payload =", adk_payload)

            resp = requests.post(ADK_RUN_URL, json=adk_payload, timeout=120)
            print("DEBUG: /run status =", resp.status_code)
            print("DEBUG: /run body   =", resp.text)

            resp.raise_for_status()
            events = resp.json()

            # Extract a simple answer from the events
            answer = extract_final_text_from_events(events)

            return jsonify({
                "answer": answer,
                "session_id":session_id,
                "user_id":user_id
            })

        except requests.exceptions.RequestException as e:
            error_message = f"Failed calling ADK at {ADK_RUN_URL}"
            print(f"ERROR: {error_message}\nDetails: {e}")
            return jsonify({"error": error_message, "details": str(e)}), 502
        except Exception as e:
            print(f"Unexpected error in Flask wrapper: {e}")
            return jsonify(
                {"error": "Internal error in Flask wrapper.", "details": str(e)}
            ), 500
    else:
        return errMessage


@app.route("/datalens/general", methods=["POST"])
def general_agent_endpoint():
    if(request.headers.get('api-key')==None):
        return errMessage
    else:
        api_key=request.headers.get('api-key').strip('"').strip('"')

    if(api_key==th_apikey):   
        data = request.get_json()
        if not data or "question" not in data:
            return jsonify({"error": "Request body must be JSON with a 'question' key."}), 400

        question = data["question"]
        #user_id = data.get("user_id", "anonymous-user")
        user_id=data["user_id"]
        session_id = data.get("session_id")
        authorization_id=data["user_id"]
        # Simple session id per user
        if not session_id:
            session_id = str(uuid.uuid4())
            label = gemini_ai.generate_session_label(question)
            print('Hello--------------------------------------')
            print(session_id,label)
            print('================================================')
            handleLabel.saveSessionLabel(authorization_id,session_id,label)
        label=handleLabel.getSessionLabel(session_id)
        print(f"DEBUG: /datainsight question from {user_id!r}: {question!r}")

        try:
            # 1) Ensure an ADK session exists
            ensure_session("GeneralAssistant", user_id, session_id)

            # 2) Build ADK /run payload (IMPORTANT: keys are camelCase)
            adk_payload = {
                "app_name": "GeneralAssistant",
                "user_id": user_id,
                "session_id": session_id,
                "new_message": {
                    "role": "user",
                    "parts": [
                        {"text": question}
                    ],
                },
                "streaming": False,
            }

            print("DEBUG: POST ADK_RUN_URL =", ADK_RUN_URL)
            print("DEBUG: payload =", adk_payload)

            resp = requests.post(ADK_RUN_URL, json=adk_payload, timeout=120)
            print("DEBUG: /run status =", resp.status_code)
            print("DEBUG: /run body   =", resp.text)

            resp.raise_for_status()
            events = resp.json()

            # Extract a simple answer from the events
            answer = extract_final_text_from_events(events)
            handleLabel.saveInteractions(authorization_id,session_id,label,question,answer)
            return jsonify({
                "question":question,
                "label":label,
                "answer": answer,
                "user_id": authorization_id,
                "session_id":session_id,
                #"events":events
            })

        except requests.exceptions.RequestException as e:
            error_message = f"Failed calling ADK at {ADK_RUN_URL}"
            print(f"ERROR: {error_message}\nDetails: {e}")
            return jsonify({"error": error_message, "details": str(e)}), 502
        except Exception as e:
            print(f"Unexpected error in Flask wrapper: {e}")
            return jsonify(
                {"error": "Internal error in Flask wrapper.", "details": str(e)}
            ), 500
    else:
        return errMessage

    
@app.route("/datalens/login/", methods=["GET", "POST"])
@app.route('/',methods=['GET'])
def callLoginCheck():
    if(request.headers.get('api-key')==None):
        return errMessage
    else:
        api_key=request.headers.get('api-key').strip('"').strip('"')

    if(api_key==th_apikey):   
        data = request.get_json()
        if not data or "username" not in data:
            return jsonify({"error": "Request body must be JSON with a 'username' key and 'password' key"}), 400
    else:
        return errMessage
        
    username=data["username"]
    password=data["password"]
    return Login().userlogin(username,password)

#  http://localhost:5000/newuser/?username=datalens@gmail.com&password=admin    
@app.route("/datalens/register/", methods=["GET", "POST"])
@app.route('/',methods=['GET'])
def callRegisterUser():
    if(request.headers.get('api-key')==None):
        return errMessage
    else:
        api_key=request.headers.get('api-key').strip('"').strip('"')

    if(api_key==th_apikey):   
        data = request.get_json()
        if not data or "username" not in data:
            return jsonify({"error": "Request body must be JSON with a 'username' key and 'password' key"}), 400
    else:
        return errMessage
        
    username=data["username"]
    password=data["password"]
    return Login().registeruser(username,password)


@app.route("/datalens/agents", methods=["POST"])
def createAgent_endpoint():
    if(request.headers.get('api-key')==None):
        return errMessage
    else:
        api_key=request.headers.get('api-key').strip('"').strip('"')

    if(api_key==th_apikey):   
        data = request.get_json()
        if not data or "agent_title" not in data:
            return jsonify({"error": "Request body must be JSON with a 'question' key."}), 400

        user_id = data["user_id"]
        agent_title = data["agent_title"]
        agent_desc = data["agent_desc"]
        business_fn = data["business_fn"]
        business_sub_fn = data["business_sub_fn"]
        agent_owner_grp = data["agent_owner_grp"]
        instructions = data["instructions"]
        source_type=data["source_type"]
        schema_txt=data["schema_txt"]
        table_list=data["table_list"]
        return handleLabel.saveAgents(user_id,agent_title,agent_desc,business_fn,business_sub_fn,agent_owner_grp,instructions,source_type,schema_txt,table_list)
    else:
        return errMessage


@app.route("/datalens/extract-data/schema", methods=["GET", "POST"])
@app.route('/',methods=['GET'])
#@app.route('/upload-profiles', methods=['POST'])
def get_schema():
    if(request.headers.get('api-key')==None):
        return errMessage
    else:
        api_key=request.headers.get('api-key').strip('"').strip('"')

    if(api_key==th_apikey):
        data = request.get_json() 
        username=data["username"]
        return datafetch().get_data(f"""
        select table_schema,table_name from information_schema.table_privileges where ltrim(rtrim(grantee))='{username}';""")
    else:
        return errMessage


@app.route("/datalens/extract-data/listagents", methods=["GET", "POST"])
@app.route('/',methods=['GET'])
#@app.route('/upload-profiles', methods=['POST'])
def get_agentlist():
    if(request.headers.get('api-key')==None):
        return errMessage
    else:
        api_key=request.headers.get('api-key').strip('"').strip('"')

    if(api_key==th_apikey):
        data = request.get_json() 
        user_id=data["user_id"]
        return datafetch().get_data(f"""
select 
        tua.agent_id
        ,ta.user_id as owner 
		,agent_owner.username owner_name
		,case when tua.user_id = ta.user_id then 'yes' else 'no' end agent_owner
        ,tua.user_id 
        ,ta.agent_title
        ,ta.agent_owner_grp
        ,ta.agent_desc 
        ,ta.business_fn 
        ,ta.business_sub_fn 
        ,ta.is_preview 
        ,ta.source_type
        ,ta.schema_txt
        ,ta.table_list
        from aiagents.tb_agents ta, aiagents.tb_userauth_agents tua,aiagents.tb_users tu,
        (select user_id,username from aiagents.tb_users) agent_owner
        where tua.agent_id::text =ta.agent_id::text 
        and tua.user_id ::text=tu.user_id::text
        and tua.user_id::text='{user_id}'
        and tua.is_active=true
        and ta.user_id=agent_owner.user_id::text;
        """)
    else:
        return errMessage   


@app.route("/datalens/extract-data/selectedmembers", methods=["GET", "POST"])
@app.route('/',methods=['GET'])
#@app.route('/upload-profiles', methods=['POST'])
def get_selectedMembers():
    if(request.headers.get('api-key')==None):
        return errMessage
    else:
        api_key=request.headers.get('api-key').strip('"').strip('"')

    if(api_key==th_apikey):
        data = request.get_json() 
        agent_id=data["agent_id"]
        return datafetch().get_data(f"""
select 
        tua.agent_id
		,agent_owner.username
        ,tua.user_id 
        from aiagents.tb_agents ta, aiagents.tb_userauth_agents tua,aiagents.tb_users tu,
        (select user_id,username from aiagents.tb_users) agent_owner
        where tua.agent_id::text =ta.agent_id::text 
        and tua.user_id ::text=tu.user_id::text
        and tua.agent_id ::text='{agent_id}'
        and tua.is_active=true
        and tua.user_id=agent_owner.user_id::text
        and case when tua.user_id = ta.user_id then 'owner' else 'user' end !='owner';
        """)
    else:
        return errMessage   



@app.route("/datalens/extract-data/labelHistory", methods=["GET", "POST"])
@app.route('/',methods=['GET'])
#@app.route('/upload-profiles', methods=['POST'])
def get_labelHistory():
    if(request.headers.get('api-key')==None):
        return errMessage
    else:
        api_key=request.headers.get('api-key').strip('"').strip('"')

    if(api_key==th_apikey):
        data = request.get_json() 
        user_id=data["user_id"]
        return datafetch().get_data(f"""
        select label_txt,sl.session_id from adk_sessions.sessions_label sl,
        (select session_id,max("timestamp") recent from adk_sessions.events e 
        where app_name ='GeneralAssistant'
        group by session_id 
        ) ts 
        where sl.session_id =ts.session_id
        and sl.user_id ='{user_id}'
        order by user_id,recent desc;
        """)
    else:
        return errMessage   

@app.route("/datalens/extract-data/convHistory", methods=["GET", "POST"])
@app.route('/',methods=['GET'])
#@app.route('/upload-profiles', methods=['POST'])
def get_convHistory():
    if(request.headers.get('api-key')==None):
        return errMessage
    else:
        api_key=request.headers.get('api-key').strip('"').strip('"')

    if(api_key==th_apikey):
        data = request.get_json() 
        session_id=data["session_id"]
        return datafetch().get_data(f"""
        WITH session_events AS (
    SELECT 
        invocation_id,
        author,
        "timestamp", -- Kept here so we can sort by it later
        content -> 'parts' -> 0 ->> 'text' AS extracted_text
    FROM events
    WHERE session_id = '{session_id}'
        )
    SELECT 
        u.extracted_text AS user_message,
        a.extracted_text AS assistant_response
    FROM session_events u
    INNER JOIN session_events a ON u.invocation_id = a.invocation_id
    WHERE u.author = 'user' 
    AND a.author = 'GeneralAssistant'
    ORDER BY u."timestamp" ASC;
        """)
    else:
        return errMessage   


@app.route("/datalens/extract-data/agentHistory", methods=["GET", "POST"])
@app.route('/',methods=['GET'])
#@app.route('/upload-profiles', methods=['POST'])
def get_agentHistory():
    if(request.headers.get('api-key')==None):
        return errMessage
    else:
        api_key=request.headers.get('api-key').strip('"').strip('"')

    if(api_key==th_apikey):
        data = request.get_json() 
        session_id=data["session_id"]
        user_id=data["user_id"]
        return datafetch().get_data(f"""
        select question as user_message,answer as assistant_response  from aiagents.tb_ai_interactions tai 
        where session_id ='{session_id}' and user_id='{user_id}'
        ORDER BY created_at ASC;
        """)
    else:
        return errMessage   


@app.route("/datalens/extract-data/agenttitle", methods=["GET", "POST"])
@app.route('/',methods=['GET'])
#@app.route('/upload-profiles', methods=['POST'])
def get_checkTitle():
    if(request.headers.get('api-key')==None):
        return errMessage
    else:
        api_key=request.headers.get('api-key').strip('"').strip('"')

    if(api_key==th_apikey):
        data = request.get_json() 
        agent_title=data["agent_title"].lower()
        return datafetch().get_data(f"""
        select count(*) cnt from aiagents.tb_agents ta where lower(agent_title)='{agent_title}'
        """)
    else:
        return errMessage   


@app.route("/datalens/extract-data/userlist", methods=["GET", "POST"])
@app.route('/',methods=['GET'])
#@app.route('/upload-profiles', methods=['POST'])
def get_userList():
    if(request.headers.get('api-key')==None):
        return errMessage
    else:
        api_key=request.headers.get('api-key').strip('"').strip('"')

    if(api_key==th_apikey):
        data = request.get_json() 
        user_id=data["user_id"]
        return datafetch().get_data(f"""select username,user_id from aiagents.tb_users tu where user_id!='{user_id}'""")
    else:
        return errMessage   
    
@app.route('/datalens/extract-data/process-actions', methods=['POST'])
def process_actions():
    # Capture the JSON body
    responseval = request.get_json(silent=True)
    data = responseval.get('user_data', [])

    if not data:
        return jsonify({"error": "Invalid JSON format"}), 400
    
    print(data)
    handleLabel.process_user_actions(responseval)
    return jsonify({
        "original_payload": data
    }), 200


if __name__ == "__main__":
    app.run()
