import json
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import matplotlib.patches as patches
from matplotlib.gridspec import GridSpec
from matplotlib.ticker import ScalarFormatter
import numpy as np
import sqlite3
import textwrap
import psycopg2
import uuid
import os
from dotenv import load_dotenv


# --- 2. Data Fetching and Visualization Functions ---
class dashTemplates(): 
    
    def __init__(self):
        load_dotenv('/home/senthil/datalens/env.txt')
        self.username=os.getenv("POSTGRES_UNAME")
        self.password=os.getenv("POSTGRES_PWD")
        self.db=os.getenv("POSTGRES_DB")
        self.host=os.getenv("POSTGRES_HOST")
        # self.USER_DB is no longer needed as we're using PostgreSQL
        # The JSON file operations will be removed.
        pass

    def dataFetch(self,SQL):
        """
        Connects to a PostgreSQL database and fetches data using the provided SQL query.
        Returns the result as a pandas DataFrame or None on error.
        """
        conn = None
        try:
            # Define PostgreSQL connection parameters
            db_params = {
                "dbname": self.db,
                "user": self.username,
                "password": self.password,
                "host": self.host,  # or your host address
                "port": "5432"        # or your port number
            }
            
            # Establish the connection to PostgreSQL
            conn = psycopg2.connect(**db_params)
            
            # Use pandas to read the SQL query directly into a DataFrame
            df = pd.read_sql_query(SQL, conn)
            return df
        
        except psycopg2.Error as e:
            print(f"PostgreSQL Error: {e}")
            return None
            
        finally:
            if conn:
                conn.close()

    def create_gauge(self,ax,value, title, min_val=0, max_val=100):
       
        # Calculate needle position (180 to 0 degrees)
        pos = 180 - (value - min_val) / (max_val - min_val) * 180
        
        # Create background arcs (Red, Orange, Green, White)
        # The '100' value at the end creates the bottom white half to hide the circle
        ax.pie([70, 20, 10, 100], 
               colors=['#ff4b4b', '#FFD6A5', '#CAFFBF', 'white'],
               startangle=180, counterclock=False, radius=1.0,
               wedgeprops={'width': 0.4, 'edgecolor': 'w'})
        
        # Calculate needle coordinates
        phi = np.radians(pos)
        ax.annotate('', xy=(0.8 * np.cos(phi), 0.8 * np.sin(phi)), xytext=(0, 0),
                    arrowprops=dict(arrowstyle='wedge,tail_width=0.5', color='black'))
        
        # Center dot and Labels
        ax.add_patch(patches.Circle((0, 0), 0.05, color='black'))
        ax.text(0, -0.25, f'{value}%', ha='center', fontsize=20, fontweight='bold')
        ax.set_title(title, pad=20)        
        ax.set_aspect('equal')
    
    def plotType(self,fig, gs, x_label, y_label,stack_label, chart_data, chart_title, position1, position2, plot_type):
        """
        Plots a chart on the specified subplot of the figure.
        """
        # Create the subplot for this chart
        ax = fig.add_subplot(gs[position1, position2])
        
        if chart_data is None or chart_data.empty:
            ax.text(0.5, 0.5, "No data available", ha='center', va='center', fontsize=12)
            ax.set_title(chart_title)
            return
    
        if plot_type == 'h_bar':
            sns.barplot(ax=ax, x=x_label, y=y_label, data=chart_data,
                        palette="pastel", edgecolor='black', linewidth=0.8)
            ax.set_title(chart_title, fontsize=12)
            labels = [textwrap.fill(label, 25) for label in chart_data[y_label]]
            ax.set_yticklabels(labels)
            ax.tick_params(axis='y', labelsize=10)
            for container in ax.containers:
                ax.bar_label(container, fmt='%.0f', padding=3, fontsize=8)
    
        if plot_type == 'v_bar':
            sns.barplot(ax=ax, x=x_label, y=y_label, data=chart_data,
                        palette="pastel", edgecolor='black', linewidth=0.8)
            ax.set_title(chart_title, fontsize=12)
            labels = [textwrap.fill(label, 15) for label in chart_data[x_label]]
            ax.set_xticklabels(labels)
            ax.yaxis.set_major_formatter(ScalarFormatter(useOffset=False))
            ax.ticklabel_format(style='plain', axis='y')
            for container in ax.containers:
                ax.bar_label(container, fmt='%.0f', padding=3, fontsize=12)
    
        
        elif plot_type == 'pie':
            colors = sns.color_palette("pastel", len(chart_data))
            wedges, texts, autotexts = ax.pie(
                chart_data[x_label], labels=chart_data[y_label], colors=colors,
                wedgeprops=dict(width=0.45, edgecolor='white'),
                startangle=90, autopct='%1.1f%%', pctdistance=1.5
            )
            ax.set_title(chart_title, pad=20, fontsize=12)

        elif plot_type == 'violin':
            df=pd.DataFrame(chart_data)
            sns.violinplot(ax = ax, x = df[x_label], y = df[y_label], palette = 'Set3',cut=1, linewidth=1 )
            ax.set_title(chart_title, fontsize=12)
        
        elif plot_type=='gauge':
            self.create_gauge(ax,int(chart_data[x_label].iloc[0]), chart_title)

        elif plot_type=='nestedpie':            
            df=pd.DataFrame(chart_data)
            # 2. Dynamic Data Preparation
            grouped = df.groupby('category', sort=False)
            categories = []
            outer_vals = []
            inner_vals = []
            inner_labels = []            
            for name, group in grouped:
                categories.append(name)
                outer_vals.append(group['value'].sum())
                inner_vals.extend(group['value'].tolist())
                inner_labels.extend(group['subcategory'].tolist())
            
            # --- SEABORN COLOR LOGIC ---
            sns.set_theme(style="white")
            # Generate a base palette for the outer categories
            # We use 'deep', 'muted', or 'bright' for distinct category colors
            base_palette = sns.color_palette("pastel", len(categories))
            
            outer_colors = []
            inner_colors = []
            
            for i, (name, group) in enumerate(grouped):
                base_color = base_palette[i]
                outer_colors.append(base_color)
                
                # Create lighter variations for the inner subcategories using sns.light_palette
                # This ensures children colors are always lighter versions of the parent
                inner_palette = sns.light_palette(base_color, n_colors=len(group) + 2, reverse=True)
                inner_colors.extend(inner_palette[1:len(group)+1])
            # ---------------------------
            
            # 3. Plotting
            #fig, ax = plt.subplots(figsize=(8, 6))
            size = 0.3
            
            # Outer Pie (Categories)
            ax.pie(outer_vals, radius=1, colors=outer_colors, labels=categories,
                   labeldistance=1.1,
                   wedgeprops=dict(width=size, edgecolor='w'))
            
            # Inner Pie (Subcategories)
            ax.pie(inner_vals, radius=1-size, colors=inner_colors, 
                   labels=inner_labels,
                   labeldistance=0.7,
                   textprops={'fontsize': 9, 'weight': 'bold', 'color': '#333333'},
                   wedgeprops=dict(width=size, edgecolor='w'))
            ax.set_title(chart_title, fontsize=12)
            ax.set(aspect="equal")
        
        elif plot_type == 'time':
            chart_data[x_label] = pd.to_datetime(chart_data[x_label])
            sns.lineplot(ax=ax, x=x_label, y=y_label, data=chart_data,
                         color="#517d82", linewidth=0.5)
            ax.fill_between(chart_data[x_label], chart_data[y_label],
                            alpha=0.05, color="#1565c0")
            ax.set_title(chart_title)
            ax.yaxis.set_major_formatter(ScalarFormatter(useOffset=False))
            ax.ticklabel_format(style='plain', axis='y')
            #ax.set_xlabel('')
            #ax.set_ylabel('')
    
        elif  plot_type=='s_bar':
            colors = sns.color_palette("pastel", 50)
            stacked_bar_data = chart_data.groupby([x_label, stack_label])[y_label].sum().unstack()
            stacked_bar_data.plot(kind='bar', stacked=True, ax=ax, color=colors, edgecolor='black')
            ax.set_title(chart_title)
            ax.set_xlabel(x_label)
            ax.set_ylabel(y_label)
            ax.tick_params(axis='x', rotation=0)
            
            # Add legend outside the plot
            ax.legend(title='Category', loc='upper left', bbox_to_anchor=(1, 1))
            ax.yaxis.set_major_formatter(ScalarFormatter(useOffset=False))
            ax.ticklabel_format(style='plain', axis='y')
    
        elif plot_type == 'scatter':
            sns.scatterplot(ax=ax, x=x_label, y=y_label, data=chart_data,
                         color="#517d82", alpha=0.7,edgecolor='black')
            ax.set_title(chart_title)
    
    # --- 3. Dashboard Generation Function ---

    def dashBoard(self,dashboard_json):
        config = json.loads(dashboard_json)
        
        sns.set_theme(style="whitegrid")
        plt.rcParams.update({
            'axes.titlesize': 14,
            'axes.titleweight': 'bold',
            'axes.labelsize': 12,
            'figure.facecolor': 'white',
            'axes.edgecolor': '#CCCCCC',
            'axes.linewidth': 1.2,
            'font.family': 'sans-serif',
        })
        
        fig = plt.figure(constrained_layout=True,figsize=(20, 12))
        plt.suptitle(config["dashboard_title"], fontsize=20, fontweight='bold', y=1.03)
        plt.subplots_adjust(top=1.88)
        gs = GridSpec(4, 2, figure=fig, height_ratios=[0.5, 2, 2, 1.5])
        #gs=GridSpec(config["dashboard_style"][0]["rows"],config["dashboard_style"][0]["columns"],figure=fig,height_ratios=[config["dashboard_style"][0]["height_ratio"]])
        
        # --- 4. Plotting Cards (Key Metrics) ---
        n_cards = len(config["cards"])
        card_colors = sns.color_palette("Set2", n_cards).as_hex()
        
        card_ax = fig.add_subplot(gs[0, :])
        card_ax.axis('off')
        
        for i, card in enumerate(config["cards"]):
            card_label = card.get("card_label")
            card_sql = card.get("card_sql")
            card_data = self.dataFetch(card_sql)
            
            if card_data is not None and not card_data.empty:
                card_value = card_data.iloc[0, 0]
                if isinstance(card_value, (int, float)):
                    formatted_value = f"${card_value:,.0f}" 
                else:
                    formatted_value = card_value
                card_text = f"{card_label}\n{formatted_value}"
            else:
                card_text = f"{card_label}\nN/A"
        
            card_width = (1.0 - 0.02 * (n_cards - 1)) / n_cards
            x_pos = 0.02 / 2 + i * (card_width + 0.02)
            ax_card = card_ax.inset_axes([x_pos, 0.15, card_width, 0.7])
            ax_card.axis('off')
        
            shadow = patches.FancyBboxPatch((0.02, 0.02), 0.96, 1.04,
                                            boxstyle="round,pad=0.2,rounding_size=0.1",
                                            facecolor='lightgray', alpha=0.3,
                                            transform=ax_card.transAxes, clip_on=False)
            ax_card.add_patch(shadow)
            rect = patches.FancyBboxPatch((0, 0), 1, 1,
                                          boxstyle="round,pad=0.2,rounding_size=0.1",
                                          facecolor='white', edgecolor=card_colors[i], linewidth=1.5,
                                          transform=ax_card.transAxes, clip_on=False)
            ax_card.add_patch(rect)
            ax_card.text(0.5, 0.5, card_text, ha='center', va='center',
                         fontsize=15, fontweight='bold', color=card_colors[i],
                         transform=ax_card.transAxes)
        
        # --- 5. Plotting Charts ---
        charts_list = config.get("charts", [])
        for chart in charts_list:
            chart_sql = chart.get("chart_sql")
            chart_data = self.dataFetch(chart_sql)
            
            self.plotType(
                fig=fig,  # Pass fig and gs explicitly
                gs=gs,
                x_label=chart.get("x_label"),
                y_label=chart.get("y_label"),
                stack_label=chart.get("stack_label"),
                chart_data=chart_data,
                chart_title=chart.get("chart_title"),
                position1=chart.get("position1"),
                position2=chart.get("position2"),
                plot_type=chart.get("plot_type")
            )
    
        # Adjust layout and show the plot
        os_path = "/home/senthil/adk_agents/chartimage/"
        #unique_name = f"{config['dashboard_title']}_{uuid.uuid4().hex[:8]}.png"  # Add file extension
        unique_name = f"{uuid.uuid4().hex[:8]}.png"  # Add file extension
        filename = os.path.join(os_path, unique_name)
        #plt.tight_layout(rect=[0, 0, 1, 0.95])
        plt.savefig(filename, dpi=75,bbox_inches='tight')
        # plt.show()
        #print(filename)
        return unique_name
    