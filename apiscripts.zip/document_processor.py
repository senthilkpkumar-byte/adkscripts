# -*- coding: utf-8 -*-
import os
import tempfile
import uuid
from flask import Blueprint, request, jsonify

# --- Import LangChain Libraries ---
from langchain_community.document_loaders import (
    PyPDFLoader, TextLoader, UnstructuredWordDocumentLoader, UnstructuredExcelLoader
)
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_google_genai import GoogleGenerativeAIEmbeddings
from langchain_community.vectorstores import Chroma

# Define the Blueprint
datalens_bp = Blueprint('datalens_bp', __name__)

# --- Configuration ---
BASE_CHROMA_DIR = "/home/senthil/adk_agents/doc_search/chroma_db/"

LOADER_MAPPING = {
    ".pdf": PyPDFLoader,
    ".txt": TextLoader,
    ".doc": UnstructuredWordDocumentLoader,
    ".docx": UnstructuredWordDocumentLoader,
    ".xls": UnstructuredExcelLoader,
    ".xlsx": UnstructuredExcelLoader,
}

def load_documents_from_files(files):
    documents = []
    with tempfile.TemporaryDirectory() as temp_dir:
        for file in files:
            try:
                temp_path = os.path.join(temp_dir, file.filename)
                file.save(temp_path)
                ext = os.path.splitext(file.filename)[1].lower()
                
                if ext in LOADER_MAPPING:
                    loader_class = LOADER_MAPPING[ext]
                    loader = loader_class(temp_path)
                    documents.extend(loader.load())
                else:
                    print(f"Warning: No loader for '{ext}'. Skipping: {file.filename}")
            except Exception as e:
                print(f"Error processing {file.filename}: {e}")
    return documents

@datalens_bp.route('/datalens/process-files', methods=['POST'])
def process_files_endpoint():
    if 'files' not in request.files:
        return jsonify({"error": "No files part"}), 400

    files = request.files.getlist('files')
    if not files or all(f.filename == '' for f in files):
        return jsonify({"error": "No selected files"}), 400

    unique_id = str(uuid.uuid4())
    dynamic_db_path = os.path.join(BASE_CHROMA_DIR, unique_id)
    os.makedirs(dynamic_db_path, exist_ok=True)

    documents = load_documents_from_files(files)
    if not documents:
        return jsonify({"error": "Could not load documents"}), 400

    text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=150)
    chunks = text_splitter.split_documents(documents)

    try:
        embedding_function = GoogleGenerativeAIEmbeddings(model="models/text-embedding-004")
        
        Chroma.from_documents(
            chunks, 
            embedding_function, 
            persist_directory=dynamic_db_path
        )

        return jsonify({
            "status": "success",
            "chroma_db_path": dynamic_db_path,
            "uuid": unique_id,
            "message": f"Processed {len(documents)} documents."
        }), 200

    except Exception as e:
        return jsonify({"error": str(e)}), 500