import os
import psycopg2
import bcrypt # For secure password hashing
#from dotenv import load_dotenv
# import hashlib # No longer needed for password hashing, replaced by bcrypt
import uuid
from flask import request, jsonify
from werkzeug.utils import secure_filename
from psycopg2 import extras


class Login:
    def __init__(self):
#        load_dotenv('/home/senthil/datalens/env.txt')
        self.username=os.getenv("POSTGRES_UNAME")
        self.password=os.getenv("POSTGRES_PWD")
        self.db=os.getenv("POSTGRES_DB")
        self.host=os.getenv("POSTGRES_HOST")
        # self.USER_DB is no longer needed as we're using PostgreSQL
        # The JSON file operations will be removed.
        pass

    def db_connection(self):
        """Establishes and returns a PostgreSQL database connection."""
        conn = None
        try:
            conn = psycopg2.connect(
                database=self.db,
                user=self.username,
                password=self.password,
                host=self.host,
                port=5432
            )
            print("Database connection successful!")
        except psycopg2.Error as e:
            print(f"Database connection failed: {e}")
            # It's good practice to re-raise or handle this error more gracefully
            # depending on your application's error handling strategy.
            raise e
        return conn

    # No longer need load_users or save_users as we're interacting directly with DB
    # def load_users(self):
    #     pass
    # def save_users(self, users):
    #     pass

    def hash_password(self, password):
        """Hashes a password using bcrypt."""
        # bcrypt.gensalt() generates a random salt and appropriate work factor
        # bcrypt.hashpw returns bytes, decode to utf-8 for storing as TEXT
        return bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')

    def check_password(self, plain_password, hashed_password):
        """Checks a plain-text password against a bcrypt hashed password."""
        # bcrypt.checkpw handles the salting and hashing internally for comparison
        return bcrypt.checkpw(plain_password.encode('utf-8'), hashed_password.encode('utf-8'))
    
    def get_client_ip(self):
        # Check if the request passed through a proxy
        if request.headers.getlist("X-Forwarded-For"):
            # The first IP in the list is the original user
            ip = request.headers.getlist("X-Forwarded-For")[0].split(',')[0]
        else:
            ip = request.remote_addr
        return ip

    def userlogin(self, iusername, ipassword):
        """
        Validates user credentials against the aiagents.tb_userauth table.
        """
        username = iusername
        password = ipassword
        userip = self.get_client_ip()

        if not username or not password:
            return {"status":"error","message": "Enter your credentials"}

        conn = None
        try:
            conn = self.db_connection()
            cursor = conn.cursor()

            # Query to find the user
            cursor.execute("SELECT password_hash,user_id FROM aiagents.tb_users WHERE username = %s", (username,))
            result = cursor.fetchone()

            if result:
                stored_password_hash = result[0]
                authorization_code=result[1]
                if self.check_password(password, stored_password_hash):
                    cursor.execute("INSERT INTO aiagents.tb_login_tracker(username,userip) VALUES (%s,%s)",(username,userip))
                    conn.commit() # Commit the transaction
                    return {"status":"success","message": "Login Successful","authorization":authorization_code}
                else:
                    return {"status":"error","message": "Incorrect password ❌"}
            else:
                return {"status":"error","message": "User does not exist, please register"}

        except psycopg2.Error as e:
            print(f"Database error during login: {e}")
            return {"status":"error","message": "An error occurred during login. Please try again later."}
        except Exception as e:
            print(f"An unexpected error occurred: {e}")
            return {"status":"error","message": "An unexpected error occurred. Please contact support."}
        finally:
            if conn:
                conn.close()

    def registeruser(self, iusername, ipassword):
        """
        Registers a new user into the aiagents.tb_userauth table.
        Hashes the password before storing.
        """
        username = iusername
        password = ipassword

        if not username or not password:
            return {"status":"error","message": "Enter your credentials"}

        conn = None
        try:
            conn = self.db_connection()
            cursor = conn.cursor()

            # Check if user already exists
            cursor.execute("SELECT username FROM aiagents.tb_users WHERE username = %s", (username,))
            if cursor.fetchone():
                return {"status":"error","message": "User already exists"}

            # Hash the password
            hashed_password = self.hash_password(password)

            # Insert new user
            cursor.execute(
                "INSERT INTO aiagents.tb_users (username, password_hash) VALUES (%s, %s)",
                (username, hashed_password)
            )
            conn.commit() # Commit the transaction

            return {"status":"success","message": "User registered successfully. Please log in."}

        except psycopg2.IntegrityError as e:
            # This catches cases like unique constraint violation if username already exists
            # although we explicitly check for it above, it's a good safeguard.
            print(f"Integrity error during registration: {e}")
            return {"status":"error","message": "User already exists or a database integrity error occurred."}
        except psycopg2.Error as e:
            print(f"Database error during registration: {e}")
            return {"status":"error","message": "An error occurred during registration. Please try again later."}
        except Exception as e:
            print(f"An unexpected error occurred: {e}")
            return {"status":"error","message": "An unexpected error occurred. Please contact support."}
        finally:
            if conn:
                conn.close()    
                
#x=Login()
#x.userlogin('datalens@gmail.com','admin')
                
                