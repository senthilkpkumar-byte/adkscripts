import os
import google.generativeai as genai
from dotenv import load_dotenv

load_dotenv()

class GeminiService:
    def __init__(self, model_name="gemini-2.0-flash"):
        self.api_key = os.getenv('GOOGLE_API_KEY')
        if not self.api_key:
            raise ValueError("GOOGLE_API_KEY not found in environment variables.")
        
        # Configure the SDK
        genai.configure(api_key=self.api_key)
        self.model = genai.GenerativeModel(model_name)
        print(f"[INFO] GeminiService initialized with {model_name}")

    def generate_session_label(self, user_prompt: str) -> str:
        """
        Generates a short descriptive label for a conversation.
        Includes a robust fix for the 'Part is not iterable' error.
        """
        prompt = f"""
        Based on the following user query, create a short, descriptive label (3-5 words).
        The label should act like a subject line or file name.
        
        User Query: "{user_prompt}"
        Label:
        """
        try:
            response = self.model.generate_content(prompt)
            
            # --- Robust Text Extraction ---
            generated_text = ""
            if response.candidates and response.candidates[0].content.parts:
                parts = response.candidates[0].content.parts
                # Check if parts is a list or a single object
                if hasattr(parts, '__iter__') and not isinstance(parts, (str, bytes)):
                    generated_text = "".join([p.text for p in parts if hasattr(p, 'text')])
                else:
                    # Single part fallback
                    generated_text = parts[0].text if hasattr(parts[0], 'text') else str(parts[0])
            else:
                generated_text = response.text

            # Cleanup string
            label = generated_text.strip().replace("*", "").replace("\"", "").replace("'", "")
            return label if len(label) > 2 else "General Conversation"

        except Exception as e:
            print(f"[GeminiService Error] {e}")
            return "General Conversation"
